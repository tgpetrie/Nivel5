#!/bin/bash
echo "🇪🇸 Iniciando Examen Final - Español 5..."
echo ""
python3 "Nivel5 guia ineractivo.py"
